package vn.co.fjs.shoppingsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoopingSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
