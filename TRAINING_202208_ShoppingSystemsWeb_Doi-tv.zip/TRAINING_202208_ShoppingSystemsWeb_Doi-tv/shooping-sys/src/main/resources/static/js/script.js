
 function check() {
//		var input = document.getElementById(id);
//		
//		var name = input.getAttribute("nameproduct");
//		var name = input.getAttribute("product-amount");
		
		alert("Hellloo");

//	 var productName = document.getElementById('productName').value;
//	 var productMount = document.getElementById('amountOrder').value;
//      if( amount%1 !==0){
//    	  document.getElementById('messageContent').innerHTML = "Số lượng đặt hàng không hợp lệ, xin hãy nhập lại! ";
//		  document.getElementById('alertMessage').style.display ="inline";
//      }
//      if(amount <=0 ){
//    	  document.getElementById('messageContent').innerHTML = "Số lượng đặt hàng của sản phẩm không hợp lệ 1 " + productMount ;
//		  document.getElementById('alertMessage').style.display ="inline"
//    	  }
      }

 function checkInputBox1(id) {
		var input = document.getElementById(id);
		let id1 = input.getAttribute("id");
		let name = input.getAttribute("nameproduct");
		let amount = input.getAttribute("product-amount");
		let inputValue = document.getElementById(id).value;
		let amountInt =parseInt(amount);
		if(inputValue < 0 && inputValue % 1 == 0){
			alert('Số lượng đặt hàng không hợp lệ, xin hãy nhập lại!' + id1);
		}else{
			if(inputValue < amountInt){
				alert('hợp lệ');
				}else{
					alert("Số lượng đặt hàng của sản phẩm " +  name + " không đủ trong kho. Xin hãy nhập số lượng <= "+amount);

				}
			}
		var xhttp = new XMLHttpRequest();
		 xhttp.open("GET", "http://localhost:8080/search/a/page/1/");
		 document.getElementById("productId1").innerHTML = id1;
		  xhttp.send();
		
//		$.ajax({
//			  type: 'GET)',
//			  url: 'http://localhost:8080/search/a/page/1',
//			  data: {(productId1:id1)},
//			  dataType: Kiểu dữ liệu trả về ('html','text','json','xml'),
//			  success: function(data) {
//			   
//			  },
//			  error: function() {
//			 
//			  }
//			});
		
		}
 
 
 