package vn.co.fjs.shoppingsys.service;

public interface TrProductOrderService {

	public String getTotalProductOrderAmount(String productId);
}
