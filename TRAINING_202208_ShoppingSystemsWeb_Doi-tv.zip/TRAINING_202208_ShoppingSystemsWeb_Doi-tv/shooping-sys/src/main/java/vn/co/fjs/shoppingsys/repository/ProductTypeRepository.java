package vn.co.fjs.shoppingsys.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.co.fjs.shoppingsys.entity.MstProductType;
@Repository
public interface ProductTypeRepository extends JpaRepository<MstProductType, String> {

	 @Query("SELECT me FROM mstproducttype me where me.status <> '1'  ")                  
	  List<MstProductType> findByTypeId();

}
