package vn.co.fjs.shoppingsys.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import vn.co.fjs.shoppingsys.entity.MstProduct;
import vn.co.fjs.shoppingsys.entity.TrProductOrder;

@Repository
public interface TrProductOrderRespository extends JpaRepository<TrProductOrder, String>{
	
//	Tính tổng sản phẩm đã order
	@Query("SELECT SUM(o.orderProductAmout) FROM trproductorder o join mstproduct p on o.id.orderProductId LIKE :productId")                  
	public String getTotalAmountOrder(@Param("productId")String productId);
	
}
