package vn.co.fjs.shoppingsys.entity;

import java.io.Serializable;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name = "mstproduct")
@Table(name = "mstproduct")
public class MstProduct implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="product_id")
	private String productId;

	@Column(name="createtime")
	private Timestamp createtime;

	@Column(name="createuser")
	private String createuser;

	@Column(name="product_amount")
	private Integer productAmount;

	@Column(name="product_description")
	private String productDescription;

	@Column(name="product_img")
	private byte[] productImg;

	@Column(name="product_name")
	private String productName;

	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "producttype_id",referencedColumnName = "producttype_id")
	private MstProductType productType;
//	@Column(name="producttype_id")
	private String productTypeId;
	

	@Column(name="status")
	private Boolean status;

	@Column(name="updatetime")
	private Timestamp updatetime;

	@Column(name="updateuser")
	private String updateuser;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Timestamp getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public Integer getProductAmount() {
		return productAmount;
	}

	public void setProductAmount(Integer productAmount) {
		this.productAmount = productAmount;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public byte[] getProductImg() {
		return productImg;
	}

	public void setProductImg(byte[] productImg) {
		this.productImg = productImg;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}



	public String getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(String productTypeId) {
		this.productTypeId = productTypeId;
	}

	public MstProductType getProductType() {
		return productType;
	}

	public void setProductType(MstProductType productType) {
		this.productType = productType;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Timestamp getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Timestamp updatetime) {
		this.updatetime = updatetime;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}
}
