package vn.co.fjs.shoppingsys.app.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import vn.co.fjs.shoppingsys.entity.MstProduct;
import vn.co.fjs.shoppingsys.entity.ProductDao;
import vn.co.fjs.shoppingsys.service.MstProductService;
import vn.co.fjs.shoppingsys.service.ProductTypeService;
import vn.co.fjs.shoppingsys.service.TrProductOrderService;

@Controller
public class ProductOrderController {
	
	@Autowired
	private ProductTypeService productTypeService;
	
//	Khởi tạo product service
	@Autowired
	private MstProductService productService;
	
//	Khởi tạo product order service
	@Autowired
	private TrProductOrderService trProductOrderService;
	
//	@RequestMapping("/order")
//	public String getProductSearch(HttpServletRequest request,Model model,
//			@RequestParam("productId11") String[] pro,@RequestParam("amount") String[] amount) {
//		
//
//		String des = (String) request.getSession().getAttribute("des");
//		String type = (String) request.getSession().getAttribute("type");
//		System.out.println("name "  + " des "+ des );
//		Map map=new HashMap();  
//		List<ProductDao> lstProductDao = new ArrayList<ProductDao>();
////		Set các giá trị cho các thuộc tính tìm kiếm
//		System.out.println(pro +" pro" + amount.length);
//		for (int i = 0; i < pro.length; i++) {
//			if(!amount[i].equals("")) {
//			map.put(pro[i], amount[i]);
//			System.out.println(map.get(pro[i]));
//			}
//		}
//		List<MstProduct> lstProduct = productService.getAllProduct();
//		List<MstProduct> lstProduct2 = new ArrayList<>();
//		for (int i = 0; i < lstProduct.size(); i++) {
//			for (int j = 0; j < map.size(); j++) {
//				if(lstProduct.get(i).getProductId().equals(pro[j])) {
//					lstProduct2.add(lstProduct.get(i));
//				}
//			}
//		}
//		for (int i = 0; i < lstProduct2.size(); i++) {
//			System.out.println(lstProduct2.get(i).getProductId() + "remove");
//		}
//		lstProductDao = convertProductDao(lstProduct2);
//		for (int i = 0; i < lstProductDao.size(); i++) {
//			for (int j = 0; j < map.size(); j++) {
//				if(lstProductDao.get(i).getProductId().equals(pro[j])) {
//					int value =Integer.parseInt(amount[j]);
//					lstProductDao.get(i).setAmountOrder(value);
//				}
//			}
//		}
//		
//		model.addAttribute("products", lstProductDao);
//		return "order";
//	}
	@RequestMapping("/index")
	public String testIndex() {


		return "index";
	}
	public List<ProductDao> convertProductDao(List<MstProduct> lstProduct){
		List<ProductDao> lstProductDao = new ArrayList<ProductDao>();
//		Set giá rị qua đối tượng product DAO
		for (int i = 0; i < lstProduct.size(); i++) {
			ProductDao pd = new ProductDao();
			pd.setProductId(lstProduct.get(i).getProductId());
			pd.setProductType(lstProduct.get(i).getProductType());
			pd.setProductName(lstProduct.get(i).getProductName());
			pd.setProductAmount(lstProduct.get(i).getProductAmount());
			pd.setProductImg(lstProduct.get(i).getProductImg());
			pd.setProductDescription(lstProduct.get(i).getProductDescription());
			String totalOrderAmountString = trProductOrderService.getTotalProductOrderAmount(lstProduct.get(i).getProductId());
			int totalOrderAmount = Integer.parseInt("0");
			pd.setTotalAmountOrder(0);
			lstProductDao.add(pd);
			System.out.println(trProductOrderService.getTotalProductOrderAmount(lstProduct.get(i).getProductId()) + "product");
		}
		return lstProductDao;
	}
	
}
