package vn.co.fjs.shoppingsys.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import vn.co.fjs.shoppingsys.repository.TrProductOrderRespository;
import vn.co.fjs.shoppingsys.service.TrProductOrderService;

@Service
@Transactional
public class TrProductOrderServiceImpl implements TrProductOrderService{

	@Autowired
	private TrProductOrderRespository trProductOrderRespository;
	
	@Override
	public String getTotalProductOrderAmount(String productId) {
		if (trProductOrderRespository.getTotalAmountOrder(productId)== null) {
			return "0";
		}
		return trProductOrderRespository.getTotalAmountOrder(productId);
	}

}
