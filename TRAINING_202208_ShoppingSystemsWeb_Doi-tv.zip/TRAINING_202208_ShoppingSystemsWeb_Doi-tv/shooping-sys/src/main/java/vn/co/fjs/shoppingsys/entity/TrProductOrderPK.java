package vn.co.fjs.shoppingsys.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the trproductorder database table.
 * 
 */
@Embeddable
public class TrProductOrderPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="order_id")
	private Integer orderId;

	@Column(name="order_customer_name")
	private String orderCustomerName;

	@Column(name="order_product_id")
	private String orderProductId;

	public TrProductOrderPK() {
	}
	public Integer getOrderId() {
		return this.orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public String getOrderCustomerName() {
		return this.orderCustomerName;
	}
	public void setOrderCustomerName(String orderCustomerName) {
		this.orderCustomerName = orderCustomerName;
	}
	public String getOrderProductId() {
		return this.orderProductId;
	}
	public void setOrderProductId(String orderProductId) {
		this.orderProductId = orderProductId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TrProductOrderPK)) {
			return false;
		}
		TrProductOrderPK castOther = (TrProductOrderPK)other;
		return 
			this.orderId.equals(castOther.orderId)
			&& this.orderCustomerName.equals(castOther.orderCustomerName)
			&& this.orderProductId.equals(castOther.orderProductId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.orderId.hashCode();
		hash = hash * prime + this.orderCustomerName.hashCode();
		hash = hash * prime + this.orderProductId.hashCode();
		
		return hash;
	}
}