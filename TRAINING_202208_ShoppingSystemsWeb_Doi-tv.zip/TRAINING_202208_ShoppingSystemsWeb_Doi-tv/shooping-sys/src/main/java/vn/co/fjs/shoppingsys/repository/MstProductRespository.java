package vn.co.fjs.shoppingsys.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import vn.co.fjs.shoppingsys.entity.MstProduct;
@Repository
public interface MstProductRespository extends JpaRepository<MstProduct, String> {
	
//	Lấy dữu liệu từ bảng "mstproduct" với điều kiện cả 3 giá trị productName, productDescription, productTypeI
	 @Query("SELECT e FROM mstproduct e join mstproducttype me ON e.productType.productTypeId like me.productTypeId where (e.productName LIKE CONCAT('%',:name,'%') AND (e.productDescription LIKE CONCAT('%',:description,'%') )) AND e.productTypeId LIKE CONCAT('%',:typeId,'%')  AND e.status <> '1' AND me.status <> '1' ORDER BY e.productAmount  ASC  ")                  
	  List<MstProduct> findByName(@Param("name")String name, @Param("description")String description, @Param("typeId")String typeid);
	 
//		Lấy dữu liệu từ bảng "mstproduct" với điều kiện 2 giá trị productName, productTypeId
	 @Query("SELECT e FROM mstproduct e join mstproducttype me ON e.productType.productTypeId like me.productTypeId where e.productName LIKE CONCAT('%',:name,'%')  AND e.productTypeId LIKE CONCAT('%',:typeId,'%')  AND e.status <> '1' AND me.status <> '1' ORDER BY e.productAmount  ASC  ")                  
	  List<MstProduct> findByName1(@Param("name")String name, @Param("typeId")String typeid);
	 
//		Lấy dữu liệu từ bảng "mstproduct" với điều kiện 2 giá trị productDescription, productTypeId
	 @Query("SELECT e FROM mstproduct e join mstproducttype me ON e.productType.productTypeId like me.productTypeId where e.productDescription LIKE CONCAT('%',:description,'%')  AND e.productTypeId LIKE CONCAT('%',:typeId,'%')  AND e.status <> '1' AND me.status <> '1' ORDER BY e.productAmount  ASC  ")                  
	  List<MstProduct> findByName2(@Param("description")String description, @Param("typeId")String typeid);
}
