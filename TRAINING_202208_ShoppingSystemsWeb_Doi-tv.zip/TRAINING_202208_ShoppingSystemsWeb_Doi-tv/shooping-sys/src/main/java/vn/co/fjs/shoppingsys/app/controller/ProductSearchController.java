package vn.co.fjs.shoppingsys.app.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import vn.co.fjs.shoppingsys.entity.MstProduct;
import vn.co.fjs.shoppingsys.entity.MstProductType;
import vn.co.fjs.shoppingsys.entity.ProductDao;
import vn.co.fjs.shoppingsys.service.MstProductService;
import vn.co.fjs.shoppingsys.service.ProductTypeService;
import vn.co.fjs.shoppingsys.service.TrProductOrderService;

@Controller
public class ProductSearchController {

//	Khởi tạo product type service
	@Autowired
	private ProductTypeService productTypeService;
	
//	Khởi tạo product service
	@Autowired
	private MstProductService productService;
	
//	Khởi tạo product order service
	@Autowired
	private TrProductOrderService trProductOrderService;
	
	@GetMapping("/search")
	public String viewAllProductS() {
		return "redirect:/search";
	}
	@RequestMapping("/search/a")
	public String getProductSearch(Model model,HttpServletRequest request, RedirectAttributes redirect,
			@ModelAttribute("product") MstProduct product,BindingResult result) {
		HttpSession session = request.getSession(true);

//		Set các giá trị cho các thuộc tính tìm kiếm
		request.getSession().setAttribute("listProduct", null);
		request.getSession().setAttribute("name", product.getProductName());
		request.getSession().setAttribute("type", product.getProductTypeId());
		request.getSession().setAttribute("des", product.getProductDescription());

		
		if(model.asMap().get("success") != null)
			redirect.addFlashAttribute("success",model.asMap().get("success").toString());
		System.out.println( product.getProductName());
		
//		Gửi các giá trị đến thymleaf
	    model.addAttribute("name", product.getProductName());
	    model.addAttribute("type", product.getProductTypeId());
	    model.addAttribute("des", product.getProductDescription());
		return "redirect:/search/a/page/1";
	}
	
//	Phân trang trang danh sách sản phẩm của trang tìm kiếm
	@GetMapping("/search/a/page/{pageNumber}")
	public String showProductSearchPage(HttpServletRequest request,
			@PathVariable int pageNumber, Model model,@ModelAttribute("product") MstProduct product,BindingResult result) {
		
//		Lấy các giá trị từ thymleaf thông qua các tên thẻ
		PagedListHolder pages = (PagedListHolder) request.getSession().getAttribute("listProduct");
		String name = (String) request.getSession().getAttribute("name");
		String des = (String) request.getSession().getAttribute("des");
		String type = (String) request.getSession().getAttribute("type");
		
		int pagesize = 2;
		String mess = "";
		String test = " test get data to js";
		
//		Lấy tất cả sản phẩm từ DB
		List<MstProduct> lstProduct = productService.getAllProduct();
		
		List<ProductDao> lstProductDao = null;
		
//		Lẩy tổng sản phẩm đã được mua
//		String totalOrderAmountString = trProductOrderService.getTotalProductOrderAmount();
//		int totalOrderAmount = Integer.parseInt(totalOrderAmountString);
		
//		Lấy 2 loại sản phẩm dầu tiên
			List<MstProductType> lstProductType = productTypeService.getAllProductTypeByStatus();
			for (int i = 2; i < lstProductType.size(); i++) {
				lstProductType.remove(i);
				i--;
			}
			
//			Các thuật toán tìm kiếm theo các giá trị truyền vào
		List<MstProduct> products = null;
		System.out.println("name: " + name +" Des: " + des);
		if(type.equals("blank")) {
			type = "";
		}
		if(name.equals("") && des.equals("") && type.equals("")) {
			products = productService.getAllProductss(name,des,type);
			lstProductDao = convertProductDao(products);
			mess = "Vui lòng nhập dữ liệu tìm kiếm";
		}else {
		if(!name.equals("") && !des.equals("")) {
		products = productService.getAllProductss(name,des,type);
		lstProductDao = convertProductDao(products);
		}else {
			if(name.equals("")) {
			products = productService.getAllProductss2(des,type);
			lstProductDao = convertProductDao(products);
			}else {
				if(des.equals("")) {
					products = productService.getAllProductss1(name,type);
					lstProductDao = convertProductDao(products);
					}
				}
		}
		}
		
//		Xác định các thông số của 1 trang trong phân trang
		System.out.println(lstProductDao.size());
		if (pages == null) {
			pages = new PagedListHolder<>(lstProductDao);
			pages.setPageSize(pagesize);
		} else {
			final int goToPage = pageNumber - 1;
			if (goToPage <= pages.getPageCount() && goToPage >= 0) {
				pages.setPage(goToPage);
			}
		}
//		Lấy danh sách sản phẩm thuộc trang hiện tại
		request.getSession().setAttribute("listProduct", pages);
		
//		Thứ tự trang(current), tổng số trang (totalPageCount)
		int current = pages.getPage() + 1;
		int begin = Math.max(1, current - lstProductDao.size());
		int end = Math.min(begin + 5, pages.getPageCount());
		int totalPageCount = pages.getPageCount();
		if(products.size()==0) {
			mess = "Không tìm thấy kết quả";
		}
		
		HttpSession session = request.getSession();
		String baseUrl = "/search/a/page/";
		model.addAttribute("pagesize", pagesize);
		model.addAttribute("beginIndex", begin);
		model.addAttribute("endIndex", end);
		model.addAttribute("currentIndex", current);
		model.addAttribute("totalPageCount", totalPageCount);
		model.addAttribute("baseUrl", baseUrl);
		model.addAttribute("products", pages);
		System.out.println( product.getProductName()+" 1 " + request.getSession().getAttribute("type"));
		model.addAttribute("name",name);
	    model.addAttribute("type", type);
	    model.addAttribute("des", des);
	    model.addAttribute("mess", mess);
		model.addAttribute("productTypes", lstProductType);
//		model.addAttribute("count", lstProduct.size());
		model.addAttribute("count", products.size());
		return "search";
	}
//	@GetMapping("/searchs")
//	public String getProductSearch(Model model,@ModelAttribute("product") MstProduct product,BindingResult result) {
//		List<MstProduct> products = productService.getAllProductss(product.getProductName(),product.getProductDescription(),product.getProductTypeId());
//	    model.addAttribute("products", products);
//	    model.addAttribute("name", product.getProductName());
//	    model.addAttribute("type", product.getProductTypeId());
//	    model.addAttribute("des", product.getProductDescription());
//	    return "search";
//	}
	public List<ProductDao> convertProductDao(List<MstProduct> lstProduct){
		List<ProductDao> lstProductDao = new ArrayList<ProductDao>();
//		Set giá rị qua đối tượng product DAO
		for (int i = 0; i < lstProduct.size(); i++) {
			ProductDao pd = new ProductDao();
			pd.setProductId(lstProduct.get(i).getProductId());
			pd.setProductType(lstProduct.get(i).getProductType());
			pd.setProductName(lstProduct.get(i).getProductName());
			pd.setProductAmount(lstProduct.get(i).getProductAmount());
			pd.setProductImg(lstProduct.get(i).getProductImg());
			pd.setProductDescription(lstProduct.get(i).getProductDescription());
			String totalOrderAmountString = trProductOrderService.getTotalProductOrderAmount(lstProduct.get(i).getProductId());
			int totalOrderAmount = Integer.parseInt("0");
			pd.setTotalAmountOrder(0);
			lstProductDao.add(pd);
			System.out.println(trProductOrderService.getTotalProductOrderAmount(lstProduct.get(i).getProductId()) + "product");
		}
		return lstProductDao;
	}
}
