package vn.co.fjs.shoppingsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import vn.co.fjs.shoppingsys.entity.MstProduct;
import vn.co.fjs.shoppingsys.repository.MstProductRespository;
import vn.co.fjs.shoppingsys.service.MstProductService;
@Service
@Transactional
public class MstProductServiceImpl implements MstProductService{
	
	@Autowired
	private MstProductRespository productRespository;
	
//	Lấy danh sách tất cả sản phẩm tư bảng
	@Override
	public List<MstProduct> getAllProduct() {
		return productRespository.findAll();
	}
	
//	Lấy danh sách sản phẩm theo tên, mô tả và loại sản phẩm
	@Override
	public List<MstProduct> getAllProductss(String name, String des, String typeid) {
		return productRespository.findByName(name,des,typeid);
	}

//	Lấy danh sách sản phẩm theo tên và mô tả
	@Override
	public List<MstProduct> getAllemployeesSearch(String productName, String productDescription) {
		List<MstProduct> products = productRespository.findAll();
		for (int i = 0; i < products.size(); i++) {
			
		}
		return null;
	}

//	Lấy danh sách sản phẩm theo tên và loại sản phẩm
	@Override
	public List<MstProduct> getAllProductss1(String name, String typeid) {
		return productRespository.findByName1(name,typeid);
	}

//	Lấy danh sách sản phẩm theo mô tả và loại sản phẩm
	@Override
	public List<MstProduct> getAllProductss2(String des, String type) {
		return productRespository.findByName2(des,type);
	}

}
//@Override
//public List<Employee> getAllemployeesSearch(String employeeName) {
//	List<Employee> employees = employeeRepository.findAll();
//	for (int i = 0; i < employees.size(); i++) {
//		if (!employees.get(i).getEmployeeName().equals(employeeName)) {
//			System.out.println(employees.get(i).equals(employeeName));
//			employees.remove(employees.get(i));
//			i--;
//		}
//	}
//	return employees;
//}