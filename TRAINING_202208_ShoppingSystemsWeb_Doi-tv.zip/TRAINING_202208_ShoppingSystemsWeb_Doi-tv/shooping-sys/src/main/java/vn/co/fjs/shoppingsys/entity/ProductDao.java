package vn.co.fjs.shoppingsys.entity;

import java.sql.Timestamp;


public class ProductDao {
	private static final long serialVersionUID = 1L;

	private String productId;

	private Timestamp createtime;

	private String createuser;

	private Integer productAmount;

	private String productDescription;

	private byte[] productImg;

	private String productName;

	private MstProductType productType;
//	@Column(name="producttype_id")
//	private String productTypeId;
	

	private Boolean status;

	private Timestamp updatetime;

	private String updateuser;
	
	private int totalAmountOrder;
	
	private int amountOrder;

	public ProductDao() {
		super();
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Timestamp getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public Integer getProductAmount() {
		return productAmount;
	}

	public void setProductAmount(Integer productAmount) {
		this.productAmount = productAmount;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public byte[] getProductImg() {
		return productImg;
	}

	public void setProductImg(byte[] productImg) {
		this.productImg = productImg;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public MstProductType getProductType() {
		return productType;
	}

	public void setProductType(MstProductType productType) {
		this.productType = productType;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Timestamp getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Timestamp updatetime) {
		this.updatetime = updatetime;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	public int getTotalAmountOrder() {
		return totalAmountOrder;
	}

	public void setTotalAmountOrder(int totalAmountOrder) {
		this.totalAmountOrder = totalAmountOrder;
	}

	public int getAmountOrder() {
		return amountOrder;
	}

	public void setAmountOrder(int amountOrder) {
		this.amountOrder = amountOrder;
	}

	
	
}
