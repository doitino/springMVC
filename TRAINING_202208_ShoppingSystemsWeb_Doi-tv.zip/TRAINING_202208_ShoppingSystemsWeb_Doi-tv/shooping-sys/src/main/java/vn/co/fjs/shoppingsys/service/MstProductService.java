package vn.co.fjs.shoppingsys.service;

import java.util.List;

import vn.co.fjs.shoppingsys.entity.MstProduct;

public interface MstProductService {
	
//	Lấy danh sách tất cả sản phẩm tư bảng
	List<MstProduct> getAllProduct();

//	Lấy danh sách sản phẩm theo tên và mô tả
	List<MstProduct> getAllemployeesSearch(String productName, String productDescription);

//	Lấy danh sách sản phẩm theo tên, mô tả và loại sản phẩm
	public List<MstProduct> getAllProductss(String name, String des, String typeid);
	
//	Lấy danh sách sản phẩm theo tên và loại sản phẩm
	public List<MstProduct> getAllProductss1(String name,  String typeid);

//	Lấy danh sách sản phẩm theo  mô tả và loại sản phẩm
	List<MstProduct> getAllProductss2(String des, String type);
}
