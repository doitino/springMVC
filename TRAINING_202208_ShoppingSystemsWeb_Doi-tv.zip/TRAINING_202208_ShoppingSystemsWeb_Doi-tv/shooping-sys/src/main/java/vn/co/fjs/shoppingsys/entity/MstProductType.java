package vn.co.fjs.shoppingsys.entity;

import java.io.Serializable;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the mstproducttype database table.
 * 
 */
@Entity(name = "mstproducttype")
@Table(name = "mstproducttype")
public class MstProductType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="producttype_id")
	private String productTypeId;
	
	@JsonIgnore
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "productTypeId")
	private Set<MstProduct> products = new HashSet<>();

	@Column(name="createtime")
	private Timestamp createtime;

	@Column(name="createuser")
	private String createuser;

	@Column(name="producttype_name")
	private String productTypeName;

	@Column(name="status")
	private Boolean status;

	@Column(name="updatetime")
	private Timestamp updatetime;

	@Column(name="updateuser")
	private String updateuser;

	public MstProductType() {
	}



	public String getProductTypeId() {
		return productTypeId;
	}



	public void setProductTypeId(String productTypeId) {
		this.productTypeId = productTypeId;
	}


	public Timestamp getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getProductTypeName() {
		return productTypeName;
	}

	public void setProductTypeName(String productTypeName) {
		this.productTypeName = productTypeName;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Timestamp getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Timestamp updatetime) {
		this.updatetime = updatetime;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	
}