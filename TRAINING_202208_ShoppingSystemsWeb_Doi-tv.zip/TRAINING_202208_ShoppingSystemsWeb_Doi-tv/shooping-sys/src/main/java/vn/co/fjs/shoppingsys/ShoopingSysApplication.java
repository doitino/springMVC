package vn.co.fjs.shoppingsys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoopingSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoopingSysApplication.class, args);
	}

}
