package vn.co.fjs.shoppingsys.service;

import java.util.List;

import vn.co.fjs.shoppingsys.entity.MstProductType;

public interface ProductTypeService {
	
	List<MstProductType> getAllProductType();
	
	List<MstProductType> getAllProductTypeByStatus();
	
	MstProductType getProductTypeById(String id);
}
