package vn.co.fjs.shoppingsys.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the trproductorder database table.
 * 
 */
@Entity(name = "trproductorder")
@Table(name = "trproductorder")
public class TrProductOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TrProductOrderPK id;

	@Column(name="createtime")
	private Timestamp createtime;

	@Column(name="createuser")
	private String createuser;

	@Column(name="order_delivery_address")
	private String orderDeliveryAddress;

	@Column(name="order_delivery_date")
	private Timestamp orderDeliveryDate;

	@Column(name="order_product_amout")
	private Integer orderProductAmout;

	@Column(name="updatetime")
	private Timestamp updatetime;

	@Column(name="updateuser")
	private String updateuser;

	public TrProductOrder() {
	}

	public TrProductOrderPK getId() {
		return this.id;
	}

	public void setId(TrProductOrderPK id) {
		this.id = id;
	}

	public Timestamp getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public String getCreateuser() {
		return this.createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getOrderDeliveryAddress() {
		return this.orderDeliveryAddress;
	}

	public void setOrderDeliveryAddress(String orderDeliveryAddress) {
		this.orderDeliveryAddress = orderDeliveryAddress;
	}

	public Timestamp getOrderDeliveryDate() {
		return this.orderDeliveryDate;
	}

	public void setOrderDeliveryDate(Timestamp orderDeliveryDate) {
		this.orderDeliveryDate = orderDeliveryDate;
	}

	public Integer getOrderProductAmout() {
		return this.orderProductAmout;
	}

	public void setOrderProductAmout(Integer orderProductAmout) {
		this.orderProductAmout = orderProductAmout;
	}

	public Timestamp getUpdatetime() {
		return this.updatetime;
	}

	public void setUpdatetime(Timestamp updatetime) {
		this.updatetime = updatetime;
	}

	public String getUpdateuser() {
		return this.updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

}