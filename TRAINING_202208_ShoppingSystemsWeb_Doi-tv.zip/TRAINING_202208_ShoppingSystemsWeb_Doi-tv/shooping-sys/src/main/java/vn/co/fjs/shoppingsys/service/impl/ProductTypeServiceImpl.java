package vn.co.fjs.shoppingsys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import vn.co.fjs.shoppingsys.entity.MstProductType;
import vn.co.fjs.shoppingsys.repository.ProductTypeRepository;
import vn.co.fjs.shoppingsys.service.ProductTypeService;

@Service
@Transactional
public class ProductTypeServiceImpl implements ProductTypeService {

	@Autowired
	private ProductTypeRepository productTypeRepository;
	
	@Override
	public List<MstProductType> getAllProductType() {
		List<MstProductType> lstProductType = productTypeRepository.findAll();
		return lstProductType;
	}

	@Override
	public MstProductType getProductTypeById(String id) {
		return productTypeRepository.findById(id).get();
	}

	@Override
	public List<MstProductType> getAllProductTypeByStatus() {
		return productTypeRepository.findByTypeId();
	}

	
}
